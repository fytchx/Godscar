# Godscar reusable UI starter · GS-UI-1.0

**Status:** working, first-pass implementation for owner visual review. **Not deployed and not applied to the Godscar repository.**

This kit converts the approved style **language** into reusable browser components instead of stretching or cropping the AI concept sheets. The supplied drawings are reference material; the code is manually reconstructed, so exact pixel-for-pixel resemblance is not claimed.

## Open the preview

Open `demo/index.html` in a browser. It uses relative paths to local CSS, JS, and SVG files and makes **no external requests**. For a phone, open the preview using a local static file server or after hosting it.

The preview shows a phone-width illustrative Fight mock and a component library side-by-side on wider displays. The mock uses only fake data, retains the portrait fight hierarchy, and does not change any of the existing site's code.

## Files

- `styles/godscar-ui.css`: scalable styles, colors, states and layouts.
- `icons/*.svg`: editable 24×24 utility icons, not gameplay/class/skill artwork.
- `ornaments/*.svg`: optional small decorative edge/diamond assets.
- `demo/index.html`, `demo/demo.js`: **working, separate browser preview** demonstrating composition and basic UI interactions.
- `references/*.png`: the user-approved concept images. These are **not** production UI sprites and should never be stretched as panels.

## Copy components into the existing Fight skeleton

Include the CSS in the root HTML `<style>` block or as a linked stylesheet:

```html
<link rel="stylesheet" href="assets/ui/godscar-ui.css">
```

Example: a reusable panel:

```html
<section class="gs-panel gs-panel--recessed">
  <header class="gs-panel__header"><h2 class="gs-heading">Activity</h2></header>
  <div class="gs-panel__body">Dynamic content here</div>
</section>
```

Example: an icon slot with a cast bar, live fill percentage and source color:

```html
<div class="gs-cast gs-source--fire" style="--value:62%">
  <div class="gs-slot"><!-- dynamic skill icon inserted here --></div>
  <div class="gs-cast__track"><i class="gs-cast__fill"></i></div>
</div>
```

Example: a fill bar in a different context:

```html
<div class="gs-progress gs-progress--health" style="--value:86%">
  <i class="gs-progress__fill"></i>
</div>
```

Text and values are HTML; only the appearance lives in CSS. Set `--value`, `--bar-color`, or one of the `gs-source--*` classes as needed. Do not change source colors to bronze.

## Reuse map

| Component | Built from | Potential screens |
|---|---|---|
| Panel | `.gs-panel` | Combat feed, stats, inventory, forge, settings |
| Dialog | `.gs-panel` + `.gs-dialog` | Offline recap, confirmation, item details |
| Buttons & tabs | `.gs-button`, `.gs-tab` | All menus |
| Icon wells | `.gs-slot` | Skills, debuffs, equipment, navigation |
| Bars | `.gs-progress`, `.gs-cast` | Health, XP, casting, status durations |
| Controls | `.gs-select`, `.gs-checkbox`, `.gs-toggle` | Enemy selection, feed filters, settings |
| Feed | `.gs-feed-shell`, `.gs-feed__row` | Combat and event activity |
| Menu | `.gs-navbar` | Five-item bottom navigation |

## Source and boundary

- Target: `fytchx/Godscar-playtest`, branch `ui/fight-skeleton`.
- Authoritative existing layout: root `index.html` based on commit `1c3adf44f1d77cc9549f8cc9b024ec6276cd253e`.
- Current Railway page is built from `main`, **not** the working UI branch.
- The current deliverable is independent code and a visual preview. It has **not** been integrated with that branch, tested against its complete interaction code, or deployed.
- No changes to `sim.js`, bots, mechanics, persistence, or other screens; no gameplay data connected.
- Production handoff: copy the stylesheet/icons into the Fight branch, map classes onto existing components without changing DOM event behavior, validate at 360/390/412/480 CSS px, and perform accessibility/performance review before asking the owner to approve preview deployment.
