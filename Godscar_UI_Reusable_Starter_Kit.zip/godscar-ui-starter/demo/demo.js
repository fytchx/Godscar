/* Presentation interactions only. No sim wiring, networking, local storage or gameplay rules. */
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const backdrop = $('#dialogBackdrop');
  const open = () => {backdrop.dataset.open='true';$('#closeModal').focus();};
  const close = () => {backdrop.dataset.open='false';$('#openModal').focus();};
  $('#openModal').addEventListener('click',open);
  $('#settingsBtn').addEventListener('click',open);
  $('#zoneBtn').addEventListener('click',open);
  $('#closeModal').addEventListener('click',close);
  $('#confirmModal').addEventListener('click',close);
  backdrop.addEventListener('click',(e)=>{if(e.target===backdrop)close();});
  document.addEventListener('keydown',(e)=>{if(e.key==='Escape'&&backdrop.dataset.open==='true')close();});
  $$('.gs-tabs .gs-tab').forEach(tab => tab.addEventListener('click',()=> {
    $$('.gs-tabs .gs-tab').forEach(t=>t.setAttribute('aria-selected',String(t===tab)));
  }));
  $('#progressSlider').addEventListener('input',e=> {
    const v=e.target.value;
    $('#progressOut').textContent=v+'%';
    $('.gallery .gs-source--fire.gs-cast').style.setProperty('--value',v+'%');
  });
  $('#feedButton').addEventListener('click',()=> {
    const list=$('#feedList'),hidden=list.hidden;
    list.hidden=!hidden;$('#feedButton span').textContent=hidden?'Hide':'Show';
  });
  $('#themeBtn').addEventListener('click',()=> {
    const dim=document.body.classList.toggle('dim-bronze');
    document.documentElement.style.setProperty('--ui-bronze',dim?'#80624b':'#a77950');
    document.documentElement.style.setProperty('--ui-highlight',dim?'#bd9670':'#e3b779');
    $('#themeBtn span').textContent=dim?'Restore bronze':'Dim bronze';
  });
  let toastTimer;
  const toast=(s)=>{clearTimeout(toastTimer);$('#toast').textContent=s;$('#toast').style.display='block';toastTimer=setTimeout(()=>{$('#toast').style.display='none'},1900);};
  $$('.gs-nav-item').forEach(el=>el.addEventListener('click',()=>{
    if(el.hasAttribute('aria-current'))return;
    toast('Demo only: other game screens stay unchanged.');
  }));
})();
